# Roshan Khokrel Khatri — IT Portfolio

A bold, modern personal IT portfolio website.

## 📁 Folder Structure

```
portfolio/
├── index.html       ← Main HTML file
├── style.css        ← All styles (dark/light mode, responsive)
├── script.js        ← Animations, interactions, form validation
└── README.md        ← This file
```

## 🚀 Deployment Guide

### Option A: GitHub Pages (Free)

1. Create a GitHub account at https://github.com
2. Create a new repository named `portfolio` (or `yourusername.github.io`)
3. Upload all three files: `index.html`, `style.css`, `script.js`
4. Go to **Settings → Pages → Source → Deploy from branch → main**
5. Your site will be live at: `https://yourusername.github.io/portfolio`

### Option B: Vercel (Recommended — Faster)

1. Go to https://vercel.com and sign up (free)
2. Click **"Add New → Project"**
3. Import your GitHub repository (connect GitHub first)
4. Click **Deploy** — done!
5. You'll get a URL like: `https://portfolio-roshan.vercel.app`

### Option C: Netlify (Also Free)

1. Go to https://netlify.com
2. Drag and drop your entire `portfolio/` folder onto the Netlify dashboard
3. You're live in seconds!

## ✨ Features

- ✅ Dark / Light mode toggle
- ✅ Animated typing effect in hero
- ✅ Scroll reveal animations
- ✅ Animated skill progress bars
- ✅ Project detail modals with pop-up
- ✅ Sticky responsive navbar
- ✅ Mobile hamburger menu
- ✅ Contact form with validation
- ✅ Scroll-to-top button
- ✅ Loading screen animation
- ✅ Glassmorphism card effects
- ✅ Grid background with glow orbs
- ✅ Active nav link on scroll

## 🛠 Customisation Tips

- **Change colour accent**: Edit `--accent: #2d7cf6` in `:root` in `style.css`
- **Add your photo**: Add `<img>` tag in the hero/about section
- **Update CV link**: Replace `href` in the Download CV button in `index.html`
- **Add more projects**: Duplicate a `.project-card` block and add a new entry in `modals` object in `script.js`
