/* ===========================
   ROSHAN KHOKREL KHATRI — PORTFOLIO JS
=========================== */

// ---- LOADER ----
window.addEventListener('load', () => {
  setTimeout(() => {
    document.getElementById('loader').classList.add('hidden');
    document.body.style.overflow = 'auto';
    triggerHeroReveal();
  }, 1600);
});
document.body.style.overflow = 'hidden';

function triggerHeroReveal() {
  document.querySelectorAll('#hero .reveal-up').forEach((el, i) => {
    setTimeout(() => el.classList.add('visible'), i * 100);
  });
}

// ---- TYPED TEXT ----
const phrases = [
  'IT Support Technician',
  'ACS Professional Year Candidate',
  'Problem Solver',
  'IT Graduate'
];
let phraseIndex = 0, charIndex = 0, isDeleting = false;
const typedEl = document.getElementById('typed-text');

function type() {
  const current = phrases[phraseIndex];
  if (isDeleting) {
    typedEl.textContent = current.substring(0, charIndex--);
    if (charIndex < 0) {
      isDeleting = false;
      phraseIndex = (phraseIndex + 1) % phrases.length;
      setTimeout(type, 400);
      return;
    }
    setTimeout(type, 50);
  } else {
    typedEl.textContent = current.substring(0, charIndex++);
    if (charIndex > current.length) {
      isDeleting = true;
      setTimeout(type, 2000);
      return;
    }
    setTimeout(type, 90);
  }
}
setTimeout(type, 2000);

// ---- NAVBAR SCROLL ----
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 50);
  document.getElementById('scrollTop').classList.toggle('visible', window.scrollY > 400);
});

// ---- SCROLL TO TOP ----
document.getElementById('scrollTop').addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

// ---- MOBILE MENU ----
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');
const menuOverlay = document.getElementById('menuOverlay');
const mobileClose = document.getElementById('mobileClose');

function openMenu() {
  mobileMenu.classList.add('open');
  menuOverlay.classList.add('show');
  document.body.style.overflow = 'hidden';
}
function closeMenu() {
  mobileMenu.classList.remove('open');
  menuOverlay.classList.remove('show');
  document.body.style.overflow = 'auto';
}
hamburger.addEventListener('click', openMenu);
mobileClose.addEventListener('click', closeMenu);
menuOverlay.addEventListener('click', closeMenu);
document.querySelectorAll('.mob-link').forEach(l => l.addEventListener('click', closeMenu));

// ---- THEME TOGGLE ----
const themeToggle = document.getElementById('themeToggle');
const themeIcon = document.getElementById('themeIcon');
let isDark = true;
themeToggle.addEventListener('click', () => {
  isDark = !isDark;
  document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
  themeIcon.className = isDark ? 'fa fa-sun' : 'fa fa-moon';
});

// ---- SCROLL REVEAL ----
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12, rootMargin: '0px 0px -50px 0px' });

document.querySelectorAll('.reveal-up, .reveal-left, .reveal-right').forEach(el => {
  if (!el.closest('#hero')) revealObserver.observe(el);
});

// ---- SKILL BAR ANIMATION ----
const skillObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.querySelectorAll('.skill-fill').forEach(fill => {
        const target = fill.getAttribute('data-width');
        setTimeout(() => { fill.style.width = target + '%'; }, 200);
      });
      skillObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.3 });

document.querySelectorAll('.skill-group').forEach(g => skillObserver.observe(g));

// ---- SMOOTH SCROLLING NAV ----
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const offset = 80;
      window.scrollTo({ top: target.offsetTop - offset, behavior: 'smooth' });
    }
  });
});

// ---- PROJECT MODALS ----
const modals = {
  grocery: {
    icon: 'fa-shopping-cart',
    title: 'Online Grocery Store Website',
    badge: '<span class="project-grade grade-hd">High Distinction</span>',
    date: 'Feb 2024',
    description: 'A fully responsive, customer-friendly e-commerce website built as a team project with two other students. The site was designed to simulate a real online grocery shopping experience with product listings, navigation, and a cart-friendly interface.',
    tools: ['HTML', 'CSS', 'JavaScript', 'Bootstrap', 'Java', 'DOM Framework', 'Conquer Template'],
    highlights: [
      'Designed and coded the front-end structure in a team of 3',
      'Utilised Bootstrap\'s Conquer Template for consistent layout',
      'Added multi-page CSS responsiveness using the DOM framework',
      'Implemented customer interaction flows across multiple pages',
      'Collaborated with team members using version control practices',
      'Achieved High Distinction grade for the project'
    ]
  },
  clothing: {
    icon: 'fa-tshirt',
    title: 'Online Clothing Store',
    badge: '<span class="project-grade grade-comp">Personal Project</span>',
    date: '2024',
    description: 'An independently built clothing e-commerce website using WordPress, demonstrating skills in content management systems, product catalogue setup, theme customisation, and web publishing.',
    tools: ['WordPress', 'CMS', 'Theme Customisation', 'E-Commerce', 'Web Design'],
    highlights: [
      'Built independently as a solo project',
      'Set up a full product catalogue with categories and images',
      'Customised WordPress theme to match brand aesthetic',
      'Configured contact, product pages, and navigation',
      'Demonstrated ability to work with CMS platforms used in business',
    ]
  }
};

function openModal(key) {
  const m = modals[key];
  document.getElementById('modalContent').innerHTML = `
    <div class="modal-icon"><i class="fa ${m.icon}"></i></div>
    <h2>${m.title}</h2>
    <div class="modal-badge">${m.badge} &nbsp; <span style="font-size:0.8rem;color:var(--text2)"><i class="fa fa-calendar"></i> ${m.date}</span></div>
    <p>${m.description}</p>
    <h4>Tech Stack</h4>
    <div class="modal-tags">${m.tools.map(t => `<span>${t}</span>`).join('')}</div>
    <h4>Key Contributions</h4>
    <ul>${m.highlights.map(h => `<li>${h}</li>`).join('')}</ul>
  `;
  document.getElementById('modalOverlay').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('open');
  document.body.style.overflow = 'auto';
}

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
});

// ---- CONTACT FORM ----
document.getElementById('contactForm').addEventListener('submit', function (e) {
  e.preventDefault();
  let valid = true;

  const fields = [
    { id: 'name', errId: 'nameErr', check: v => v.trim().length > 1 },
    { id: 'email', errId: 'emailErr', check: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) },
    { id: 'subject', errId: 'subjectErr', check: v => v.trim().length > 2 },
    { id: 'message', errId: 'msgErr', check: v => v.trim().length > 5 }
  ];

  fields.forEach(({ id, errId, check }) => {
    const input = document.getElementById(id);
    const group = input.closest('.form-group');
    if (!check(input.value)) {
      group.classList.add('error');
      valid = false;
    } else {
      group.classList.remove('error');
    }
  });

  if (valid) {
    const btn = this.querySelector('button[type="submit"]');
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Sending...';
    btn.disabled = true;
    setTimeout(() => {
      this.reset();
      btn.innerHTML = '<i class="fa fa-paper-plane"></i> Send Message';
      btn.disabled = false;
      document.getElementById('formSuccess').classList.add('show');
      setTimeout(() => document.getElementById('formSuccess').classList.remove('show'), 4000);
    }, 1500);
  }
});

// Live validation clear
document.querySelectorAll('.form-group input, .form-group textarea').forEach(input => {
  input.addEventListener('input', () => {
    input.closest('.form-group').classList.remove('error');
  });
});

// ---- ACTIVE NAV LINK ----
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-link');

window.addEventListener('scroll', () => {
  let current = '';
  sections.forEach(s => {
    if (window.scrollY >= s.offsetTop - 200) current = s.getAttribute('id');
  });
  navLinks.forEach(link => {
    link.style.color = link.getAttribute('href') === `#${current}` ? 'var(--accent)' : '';
  });
}, { passive: true });
